#!/bin/bash

# MMSI
# Manjaro Maui Shell Installer v0.0.2
# License: GPL v3.0
# Author: Cara Oswin
# Copyright: 2022, GPL v3.0
	
# Notes: This is a script to help Pinephone Pro owners running Manjaro (tested with Phosh) install the convergent shell for desktops, tablets, and phones; Maui-Shell on their Pinephone Pro. It's possible it's also compatible with OG pinephones on manjaro / arch, i've not tested it, and wouldn't recomend doing so due to speed concerns.

options[0]="Create Desktop icon for this program
            (Work in progress / broken)"
options[1]="Install Dependencies"
options[2]="Install Maui-Shell"
options[3]="Create Script to start
            Maui-Shell"
options[4]="Set Maui-Shell to launch
            at startup
            (WARNING may be system-breaking,
            do not use un-prepared)
            (Work in progress / Broken)"
options[5]="Lunch Maui Shell"
options[6]="Exit (ctrl + c)"


#Actions to take based on selection
function ACTIONS {
    if [[ ${choices[0]} ]]; then
# Create Desktop icon for this program
        sudo mkdir /home/manjaro/Documents/MMSI
        sudo cp MMSI.sh /home/manjaro/Documents/MMSI
        sudo cp icon.png /home/manjaro/Documents/MMSI
        cd  /home/manjaro/.local/share/applications
        touch MMSI.desktop
        echo "[Desktop Entry]
Encoding=UTF-8
Type=Application
NoDisplay=false
Terminal=true
Exec=bash /home/manjaro/Documents/MMSI/./MMSI.sh
Path=/home/manjaro/Documents/MMSI
Icon=/home/manjaro/Documents/MMSI/icon.png
Name=MMSI
Comment=Install Maui Shell on Pinephone Pros on Manjaro">MMSI.desktop
        sudo chmod +x MMSI.desktop
        sudo desktop-file-install MMSI.desktop
    fi
    if [[ ${choices[1]} ]]; then
    # Install Dependencies
        echo "This will install yay, git, and ..."
        read -p "Press 'enter' to continue, or ctrl + c to cancel"
        sudo pacman -S base-devel git
        git clone https://aur.archlinux.org/yay-git.git
        cd yay-git
        makepkg -si
        cd ..
        ./MMSI.sh
    fi
    if [[ ${choices[2]} ]]; then
    # Install Maui-Shell
        yay -S maui-shell-git
        ./MMSI.sh
    fi   
    if [[ ${choices[3]} ]]; then
    # Create Script to start Maui-Shell
        echo "this will create a startup script for Maui-shell"
        touch Start-Maui-Shell.sh
        echo "#!/bin/sh
        # in case it's not detected
        # or you wish to override 
        #
        export QT_QPA_EGLFS_PHYSICAL_WIDTH=720 
        export QT_QPA_EGLFS_PHYSICAL_HEIGHT=1440 
        export QT_QPA_PLATFORM=eglfs
        export QT_AUTO_SCREEN_SCALE_FACTOR=0
        export QT_SCALE_FACTOR=2
        cask -r -plugin libinput">Start-Maui-Shell.sh
        chmod +x Start-Maui-Shell.sh
        ./MMSI.sh
    fi
    if [[ ${choices[4]} ]]; then
    # Set Maui-Shell to launch at startup
        echo "This will set Maui-Shell to launch at 
        startup, this option is dangerous, and could
        result in you needing to re-install your os"
        read -p "Press 'enter' to continue, or ctrl + c to cancel"
        sh ~/Start-Maui-Shell.sh
        chmod +x ~/Start-Maui-Shell.sh
        ./MMSI.sh
    fi
    if [[ ${choices[5]} ]]; then
# Launch Maui Shell
        ./Start-Maui-Shell.sh
    fi
    if [[ ${choices[6]} ]]; then
    # Exit
        echo "Bye!"
        exit
    fi
}

#Variables 
ERROR= ""

#Clear screen for menu
clear

#Menu function
function MENU {
    echo "       MMSI Menu v0.0.2
  
 
  
___________________________ 
|                  __  __  |
|      __  __  __ / / / /  |
|     / / / / / // / /_/   |
|    / / /_/ / // /        |
|   /_/     /_//_/         |
|                          |
|__________________________|
| GPL 3.0, 2022, Cara Oswin|
|__________________________|




"
    for NUM in ${!options[@]}; do
        echo "[""${choices[NUM]:- }""]" $(( NUM+1 ))") ${options[NUM]}"
    done
    echo "$ERROR"
}

#Menu loop
while MENU && read -e -p "Please make a choice.. " -n1 SELECTION && [[ -n "$SELECTION" ]]; do
    clear
    if [[ "$SELECTION" == *[[:digit:]]* && $SELECTION -ge 1 && $SELECTION -le ${#options[@]} ]]; then
        (( SELECTION-- ))
        if [[ "${choices[SELECTION]}" == "+" ]]; then
            choices[SELECTION]=""
        else
            choices[SELECTION]="+"
        fi
            ERROR=" "
    else
        ERROR="Invalid option: $SELECTION"
    fi
done

ACTIONS
